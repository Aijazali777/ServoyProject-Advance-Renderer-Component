/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"499CEF34-7F49-4ECB-9BB3-9D56D49B4BC3"}
 */
var customer_name = " ";
/**
 * @properties={typeid:35,uuid:"7C3E7125-944D-41DC-8F3C-91981AAA1825",variableType:-4}
 */
var buy_date = null;

/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"67F9631E-88DE-4F55-9172-63F84AFF9CA1"}
 */
var displayAddedFeatures = " ";
/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"936AF4C3-3EB3-4B00-98F1-6564722C532F"}
 */
function onAddFeatures(event)
{
	var win = application.createWindow("featuresList",JSWindow.MODAL_DIALOG, application.getWindow('customersDetail'));
	win.setInitialBounds(20, 20, 640, 480);
	//displayAddedFeatures = " ";
	win.title = "Add Features";
	win.show(forms.featuresList);
}
/**
 * @properties={typeid:24,uuid:"20C74541-403B-4BEF-BFEF-3A7D22475318"}
 */
function clearfields()
{
	customer_name = " ";
	buy_date = null;
	displayAddedFeatures = " ";
}

/**
 * @properties={typeid:24,uuid:"C1F0F10C-9832-44EB-A203-FCC5C786DB6B"}
 */
function assignFiledsFromDB()
{
	customer_name = customername;
	buy_date = buydate;
	
	var theQuery = "SELECT added_features FROM abcsoftwares INNER JOIN   addedfeatures  ON abcsoftwares.customername = addedfeatures.customername";
	var theDataset = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery,null, -1);
	displayAddedFeatures = theDataset //foundset.abcsoftwares_to_addedfeatures.added_features;
}

/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"6587FE55-BCAD-4F23-8DE0-8C6615D23997"}
 */
function onSave(event)
{
	foundset.customername = customer_name;
	foundset.buydate = buy_date;
	databaseManager.saveData(foundset);
	application.getActiveWindow().hide();
}

/**
 * Handle hide window.
 *
 * @param {JSEvent} event the event that triggered the action
 *
 * @return {Boolean}
 *
 * @properties={typeid:24,uuid:"4E9608C2-36B1-4B2D-A12F-042047442B04"}
 */
function onHide(event)
{
	//displayAddedFeatures = " ";
	forms.MainForm.existingCustomer= 0;
	return true
}

