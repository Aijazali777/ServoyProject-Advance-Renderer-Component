/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"76AF7F9B-C32D-4EFD-8A7C-48147579D50C"}
 */
var feature;
/**
 * @properties={typeid:35,uuid:"12CCA71D-0FFB-4520-A811-9164279F0862",variableType:-4}
 */
var addedFeatures = [];
/**
 * Callback method when form is (re)loaded.
 *
 * @param {JSEvent} event the event that triggered the action
 *
 * @private
 *
 * @properties={typeid:24,uuid:"2E0EEF0F-D441-4219-9FB4-C216DF5F3F3C"}
 */
function onLoad(event)
{
	var renderFunction = scopes.svySystem.printMethodCode(renderEntry).join("\n");
	elements.list1.entryRendererFunction = renderFunction;
	databaseManager.refreshRecordFromDatabase(foundset,-1);
	setListEntries();
	setListEntrie2s();
}

/**
 * Creates the entries shown in the list from a dataset
 * @private 
 * @properties={typeid:24,uuid:"3BD2DB3F-F24F-4F8B-BD27-96D562919FBC"}
 */
function setListEntries()
{
	//var existingCustomer = foundset.customername
	if(forms.MainForm.existingCustomer == '1')
	{
		var theQuery = "SELECT features_list FROM featureslist WHERE features_list <> (SELECT added_features FROM abcsoftwares INNER JOIN   addedfeatures  ON abcsoftwares.customername = addedfeatures.customername LIMIT 1 )";
		var ds = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery,null, -1);
		
		//var q = datasources.db.example_data.featureslist.createSelect(); //.featureslist.createSelect();
		//q.result.add(q.columns.features_list);
		//var ds = databaseManager.getDataSetByQuery(theQuery, -1);
		
		application.output(ds);
		
		var entries = [];
		for (var i = 1; i <= ds.getMaxRowIndex(); i++)
		{
			var row = ds.getRowAsArray(i);
			var entry = {features_list: row[0]}
			entries.push(entry);
		}
		elements.list1.setEntries(entries);
	}
	else
	{
		var q = datasources.db.example_data.featureslist.createSelect(); //.featureslist.createSelect();
		q.result.add(q.columns.features_list);
		 ds = databaseManager.getDataSetByQuery(q, -1);
		
		application.output(ds);
		
		 entries = [];
		for ( i = 1; i <= ds.getMaxRowIndex(); i++)
		{
			 row = ds.getRowAsArray(i);
			 entry = {features_list: row[0]}
			entries.push(entry);
		}
		elements.list1.setEntries(entries);
	}
}

/**
 * Creates the entries shown in the list from a dataset
 * @private 
 * @properties={typeid:24,uuid:"B8FA07C4-12F4-4D7E-A4A0-C05C0199EEB4"}
 */
function setListEntrie2s()
{
	if(forms.MainForm.existingCustomer  == '1')
	{
		var theQuery = "SELECT added_features FROM abcsoftwares INNER JOIN   addedfeatures  ON abcsoftwares.customername = addedfeatures.customername";
		var ds = databaseManager.getDataSetByQuery(databaseManager.getDataSourceServerName(controller.getDataSource()), theQuery,null, -1);
		
		//var q = datasources.db.example_data.featureslist.createSelect(); //.featureslist.createSelect();
		//q.result.add(q.columns.features_list);
		//var ds = databaseManager.getDataSetByQuery(theQuery, -1);
		
		application.output(ds);
		
		var entries = [];
		for (var i = 1; i <= ds.getMaxRowIndex(); i++)
		{
			var row = ds.getRowAsArray(i);
			var entry = {features_list: row[0]}
			entries.push(entry);
		}
		elements.list1.setEntries(entries);
	}
	else
	{
		var q = datasources.db.example_data.featurestable.createSelect();
		q.result.add(q.columns.customfeatures);
		ds = databaseManager.getDataSetByQuery(q, -1);
		
		entries = [];
		for (i = 1; i <= ds.getMaxRowIndex(); i++)
		{
			row = ds.getRowAsArray(i);
			entry = {customfeatures: row[0]}
			entries.push(entry);
		}
		elements.list2.setEntries(entries);
	}
}

/**
 * To allow to easily write the renderer Function in Servoy, the example attaches the function to the list in the onLoad of this form
 * 
 * @private 
 * @param entry
 * @return {}
 * @properties={typeid:24,uuid:"2166F400-696A-4291-B66C-69C8C17101AD"}
 */
function renderEntry(entry)
{
	var template = '<div class="product-row">';
	template += '<div class="product" data-target="product-name" svy-tooltip="tooltipFunction(null, entry)">' + entry.features_list; '</div>';
	return template;
}
/**
 * @param {JSEvent} event
 * @param {Array<number>} oldIndicies
 * @param {Array<number>} newIndicies
 * @param {Array<object>} entriesMoved
 * @param {Array<object>} entriesMovedTo
 *
 * @protected
 *
 * @properties={typeid:24,uuid:"95C701C6-6016-47B1-B3DB-F50DC0740F54"}
 */
function onDrop(event, oldIndicies, newIndicies, entriesMoved, entriesMovedTo)
{
	for (var i = 0; i < entriesMoved.length; i++)
	{
		feature = entriesMoved[i].features_list;
		//application.output(entriesMoved[i].applicationfeatures);
	}
	
	if(addedFeatures.indexOf(feature) >= 0)
	{
		addedFeatures.splice(addedFeatures.indexOf(feature),1);
	}
	forms.customersDetail.displayAddedFeatures = addedFeatures.join('\n');
}

/**
 * @param {JSEvent} event
 * @param {Array<number>} oldIndicies
 * @param {Array<number>} newIndicies
 * @param {Array<number>} entriesMoved
 * @param {Array<object>} entriesMovedTo
 *
 * @public
 *
 * @properties={typeid:24,uuid:"84BCA1DB-3D39-47D5-9CE2-AE1F5BB9B3CB"}
 */
function onDrop2(event, oldIndicies, newIndicies, entriesMoved, entriesMovedTo)
{	
	
	for (var i = 0; i < entriesMoved.length; i++)
	{
		feature = entriesMoved[i].features_list;
		//application.output(entriesMoved[i].applicationfeatures);
	}
	addedFeatures.push(feature);
	forms.customersDetail.displayAddedFeatures = addedFeatures.join('\n');
}
/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"D30F0389-280B-4D68-B96B-E24DC170F7A8"}
 */
function onDone(event)
{
	var arraySize = addedFeatures.length;
	
	application.output(arraySize);
	
	for(var i = 0; i < arraySize; i++)
	{
		foundset.newRecord();
		foundset.customername = forms.customersDetail.customer_name;
		foundset.added_features = addedFeatures[i];
		databaseManager.saveData(foundset);
	}
	
	for(i = 0; i < arraySize; i++)
	{
		application.output(addedFeatures.pop());
		
	}
	application.getActiveWindow().hide();
}

