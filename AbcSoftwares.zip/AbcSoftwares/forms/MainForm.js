/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"71433A76-58FC-4B36-8F1C-44B70264D45B"}
 */
var about = "ABC softwares is a company that specializes in building software products. Such companies can focus on business or consumer software – for example, out-of-the-box, single license software, or products like Software-as-a-Service (SaaS)";
/**
 * @type {String}
 *
 * @properties={typeid:35,uuid:"CF1E0327-C00D-4D5E-AF79-0E9CCA2B29E4"}
 */
var disclaimer = "The ABC Software's Owner makes no warranty that all Errors have been or can be eliminated from the Software Code or Documentation or that the New Software Code can be written or developed which will permit the Developer to develop a Beta Version of the Advanced Modeler";
/**
 * @type {Number}
 *
 * @properties={typeid:35,uuid:"7A4D24B6-41C3-419B-8E4E-51F8988C638F",variableType:4}
 */
var existingCustomer = 0;
/**
 * TODO generated, please specify type and doc for the params
 * @param event
 *
 * @properties={typeid:24,uuid:"3884E984-7847-4820-B8EC-6FA7BE89D3D2"}
 */
function onAddNewCustomer(event)
{
	var win = application.createWindow("customersDetail",JSWindow.MODAL_DIALOG, application.getWindow('MainForm'));
	win.setInitialBounds(-1, -1, 640, 480);
	win.title = "Add a new record";
	forms.customersDetail.clearfields();
	foundset.newRecord();
	win.show(forms.customersDetail);


}

/**
 * @param {JSEvent} event
 *
 * @properties={typeid:24,uuid:"A8A4B829-4126-4E45-AD9D-58CA8DD6EE38"}
 */
function onExistingCustomer(event)
{
	var win = application.createWindow("customersDetail",JSWindow.MODAL_DIALOG, application.getWindow('MainForm'));
	win.setInitialBounds(-1, -1, 640, 480);
	forms.customersDetail.assignFiledsFromDB();
	existingCustomer = 1;
	win.title = "Edit Existing Customer";
	win.show(forms.customersDetail);
}
